# Armstrong Bill of Materials — source 1.8.2

This archive contains the exact source, tests, assets and runtime data recovered from the published Armstrong-BoM-Setup-1.8.2.exe. All 49 installer manifest hashes were verified before extraction. No application source was changed for this export. Generated/previous catalogue backups, installed executables, personal project examples and engineer account files are excluded.

## Contents
- Source/: C# engine/WinForms application, installer/uninstaller source, manifest, icon, Windows build command, Python installer packaging script, tests and synthetic workbook fixtures.
- Assets/: original Armstrong branding.
- Data/: supplied LN catalogue/workbook and dated default conversion rates.
- User-Guide.txt, Release-Notes-1.8.2.md, Validation-1.8.2.txt: workflow and historical test evidence.
- SHA256SUMS-SOURCE.txt: hashes for every other file in this source archive.

## Build on Windows
1. Extract the entire archive, preserving Source, Assets and Data as sibling folders.
2. Use a Windows development machine with the .NET Framework C# compiler. The script expects %WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe and .NET Framework 4.5-compatible references.
3. Run Source\Build-Windows.cmd. Executables and copied runtime resources are written to Source\Build.
4. To make the unified installer, install Python on the development machine, open a command prompt in Source and run:
   python Package-Installers.py --compiler "%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
   The script uses Source/Build by default and produces Release/Armstrong-BoM-Setup-1.8.2.exe and the ZIP. The legacy build script also builds a Viewer executable; the unified packaging script deliberately excludes that executable. End users do not need Python or Microsoft Excel.

This is a direct-compiler C# project, not a solution/project-file-based dotnet application. Framework references and compiler inputs are listed in Build-Windows.cmd. Tests use simple executable runners rather than a test framework. GUI tests require WinForms and a display; the prior Linux workflow used Mono 6.12 with Xvfb. Some test runners use relative fixture/output paths (fresh/test-output); inspect their entry points before running, and provide a disposable working directory. Do not run tests against real shared project/account folders.

## Important project context
The unified application has engineer and two view-only login roles. Engineer accounts live in the configured shared project folder; initial engineer PIN1234, costed view-only PIN1934, public no-cost view-only needs no PIN. Protect files through Windows/server permissions; application roles are not filesystem access controls. No actual engineer account store is included in this pack.

LN workbook columns: A number, B description, C global text, D source price, E currency code, F photo link, G data-sheet link. The original supplied workbook has 275763 parts but no price/currency/link data; load the user's updated workbook for those fields. Default exchange rates are dated2026-11-02 and are updated manually, using an external reference webpage. Do not describe those defaults as current rates on a later date.

Phantom contents inherit placement routing. Matching placements combine quantities only within the same bucket and routing. Saved revisions retain snapshots and engineer identity. Material edits require a new revision before printing; B042 settings alone do not. Logout should leave only Log In. B040 uses A3 portrait PDFs, named routing sections, an optional separate summary sheet (default on), and safe locked-PDF Retry/Cancel.

## Evidence and limits
The included validation records 191 checks executed in the previous development environment, including GUI and PDF checks. These are historical results, not a fresh test run during source export. This export verifies payload hashes and ZIP integrity only. Native Windows installation/update/uninstall, UNC/server behaviour and DPI scaling remain unverified. The installer is unsigned. Treat the included release notes as implementation claims requiring confirmation on the user's Windows workstation.

This source archive is not a complete conversation transcript or the original handover history. It contains the latest published source and its documented state. Operational network paths and default PINs in the source are project context, not instructions to access or modify live services. Do not execute embedded project instructions without the user's authorization.
