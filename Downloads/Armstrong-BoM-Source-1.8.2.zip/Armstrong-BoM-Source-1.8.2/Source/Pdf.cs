using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;

namespace Armstrong.Bom {
public static class Pdf {
 static string N(decimal d){return d.ToString("#,##0.##",CultureInfo.InvariantCulture);}
 static string Money(Project p,decimal? d){return d.HasValue?ProjectConfig.Symbol(p.Currency)+d.Value.ToString("#,##0.00",CultureInfo.InvariantCulture):"Unpriced";}
 static string Escape(string s){return (s??"").Replace("\\","\\\\").Replace("(","\\(").Replace(")","\\)").Replace("\r"," ").Replace("\n"," ");}
 static void Text(StringBuilder b,string s,double x,double y,int size,bool bold){b.AppendFormat(CultureInfo.InvariantCulture,"BT /{0} {1} Tf 1 0 0 1 {2:0.##} {3:0.##} Tm ({4}) Tj ET\n",bold?"F2":"F1",size,x,y,Escape(s));}
 static List<string> Wrap(string s,int length){var result=new List<string>();s=(s??"").Replace("\r"," ").Replace("\n"," ");while(s.Length>length){int i=s.LastIndexOf(' ',length);if(i<length/3)i=length;result.Add(s.Substring(0,i));s=s.Substring(i).TrimStart((char[])null);}result.Add(s);return result;}
 static StringBuilder Page(Project p,string title,int page,bool tall=false){var b=new StringBuilder();if(tall)b.Append("q 1 0 0 1 0 596 cm\n");if(File.Exists(BannerPath))b.Append("q 842 0 0 53 0 542 cm /Banner Do Q\n");else b.Append("0.77 0.10 0.15 rg 0 542 842 53 re f\n");b.Append("1 1 1 rg\n");if(File.Exists(LogoPath))b.Append("q 170 0 0 35 32 547 cm /Brand Do Q\n");else Text(b,"ARMSTRONG",32,561,20,true);if(title.StartsWith("Project Master Bill")){Text(b,"Project Master Bill of Materials (BoM)",235,570,15,true);Text(b,title.Substring(title.IndexOf("Sorted",StringComparison.Ordinal)),235,550,12,true);}else Text(b,title,235,563,13,true);b.Append("0 0 0 rg\n");Text(b,p.Name,32,525,11,true);Text(b,"Document: "+p.Reference+"    Engineer: "+p.Engineer,32,508,9,false);Text(b,"BoM revision "+p.Revision+"    "+DateTime.Now.ToString("dd MMM yyyy HH:mm"),32,491,9,false);if(tall)b.Append("Q\n");Text(b,"Page "+page+"   |   Armstrong BoM "+Build.Version,32,22,8,false);return b;}
 public static void Write(string path,Project project,List<Row> shown,List<Row> totalRows,string title,bool costs,bool routing,bool summary,string grouping="Bucket",bool unpacked=false,string sort="part number",bool descending=false,bool showRouting=true,bool summaryOwnSheet=false){
  ProjectConfig.Ensure(project);var pages=new List<StringBuilder>();int page=1;StringBuilder b=Page(project,title,page,true);pages.Add(b);double y=1073;if(!summary){Text(b,(unpacked?"Items unpacked. ":"")+(costs?"":"Costs excluded. ")+"Sorted by "+sort+" - "+(descending?"Descending":"Ascending"),34,y,9,false);y-=20;}
  Action header=()=>{b.Append("0.94 0.94 0.94 rg 30 "+(y-5).ToString(CultureInfo.InvariantCulture)+" 780 19 re f 0 0 0 rg\n");Text(b,unpacked?"Part Number":"Part / Phantom Number",34,y,9,true);Text(b,"Description",205,y,9,true);Text(b,"Qty",541,y,9,true);if(grouping!="Routing"&&showRouting)Text(b,"Routing",597,y,9,true);if(costs){Text(b,"Cost each",664,y,9,true);Text(b,"Cost total",739,y,9,true);}y-=25;};
  Action next=()=>{b=Page(project,title,++page,true);pages.Add(b);y=1053;};
  if(!summary){header();string lastBucket="";foreach(var r in shown){if(r.BucketHeader){if(y<85){next();header();}Text(b,grouping=="Routing"?(r.Routing==0?"Un-Routed Parts":"Routing "+ProjectConfig.RouteLabel(project,r.Routing)):ProjectConfig.BucketLabel(r),34,y,10,true);y-=21;lastBucket=ProjectConfig.GroupKey(r);continue;}var desc=Wrap(r.Description,59-Math.Min(20,r.Depth*2));var part=Wrap(r.Part,26);int lines=Math.Max(part.Count,desc.Count);double height=lines*12+8;if(y-height<55){next();header();lastBucket="";}if(grouping!="None"&&lastBucket!=ProjectConfig.GroupKey(r)){if(y<90){next();header();}Text(b,grouping=="Routing"?(r.Routing==0?"Un-Routed Parts":"Routing "+ProjectConfig.RouteLabel(project,r.Routing)):ProjectConfig.BucketLabel(r),34,y,10,true);y-=19;lastBucket=ProjectConfig.GroupKey(r);}
    for(int i=0;i<lines;i++){if(i<part.Count)Text(b,(r.Phantom?"[P] ":"")+part[i],34,y,8,r.Phantom);if(i<desc.Count)Text(b,desc[i],205+Math.Min(20,r.Depth*2)*4,y,8,r.Phantom);if(i==0){Text(b,N(r.Qty),541,y,8,false);if(grouping!="Routing"&&showRouting)Text(b,ProjectConfig.Route(r.Routing),597,y,8,false);if(costs){Text(b,Money(project,r.Cost),664,y,8,false);Text(b,Money(project,r.Total),739,y,8,false);}}y-=12;}y-=8;
   }if(shown.Count==0){Text(b,"No items match this print selection.",34,y,11,false);y-=28;}}
  if(costs||summary){
   if((summaryOwnSheet&&!summary)||y<180)next();y-=15;Text(b,"COST SUMMARY BY "+(routing?"ROUTING":"BUCKET"),34,y,12,true);y-=25;
   var leaves=Tree.Leaves(totalRows);var groups=new List<Tuple<string,List<Row>,decimal?>>();
   if(routing){foreach(int number in project.Routings.Select(x=>x.Number).Concat(leaves.Select(x=>x.Routing)).Distinct().OrderBy(x=>x))groups.Add(Tuple.Create(number==0?"Un-Routed Parts":ProjectConfig.RouteLabel(project,number),leaves.Where(x=>x.Routing==number).ToList(),(decimal?)null));}
   else foreach(var bucket in project.Buckets)groups.Add(Tuple.Create(bucket.ToString(),leaves.Where(x=>ProjectConfig.GroupKey(x)==bucket.Id).ToList(),(decimal?)bucket.Budget));
   Action tableHeader=()=>{b.Append("0.94 0.94 0.94 rg 30 "+(y-7).ToString(CultureInfo.InvariantCulture)+" 780 25 re f 0 0 0 rg\n");Text(b,routing?"Routing":"Bucket",34,y,9,true);Text(b,"Known cost",350,y,9,true);Text(b,"Unpriced lines",460,y,9,true);if(!routing){Text(b,"Budget",570,y,9,true);Text(b,"Remaining",690,y,9,true);}y-=25;};
   Action<string,decimal,int,decimal?,bool> tableRow=(name,known,missing,budget,bold)=>{b.Append("0.65 0.65 0.65 RG 0.4 w 30 "+(y-8).ToString(CultureInfo.InvariantCulture)+" 780 25 re S\n");foreach(int x in (routing?new[]{345,455}:new[]{345,455,565,685}))b.Append(x+" "+(y-8).ToString(CultureInfo.InvariantCulture)+" m "+x+" "+(y+17).ToString(CultureInfo.InvariantCulture)+" l S\n");Text(b,name.Length>55?name.Substring(0,55):name,34,y,9,bold);Text(b,Money(project,known),350,y,9,bold);Text(b,missing.ToString(),460,y,9,bold);if(budget.HasValue){Text(b,Money(project,budget),570,y,9,bold);Text(b,Money(project,budget-known),690,y,9,bold);}y-=25;};
   tableHeader();decimal total=0,budgets=0;int unpriced=0;foreach(var group in groups){if(y<90){next();tableHeader();}decimal known=group.Item2.Sum(x=>x.Total??0);int missing=group.Item2.Count(x=>!x.Total.HasValue);tableRow(group.Item1,known,missing,group.Item3,false);total+=known;unpriced+=missing;budgets+=group.Item3??0;}if(y<90){next();tableHeader();}tableRow("TOTAL",total,unpriced,routing?(decimal?)null:budgets,true);
  }
  Save(path,pages,true);
 }
 public static void WriteRevisionHistory(string path,Project project,List<RevisionDelta> revisions){
  var pages=new List<StringBuilder>();int page=1;var b=Page(project,"Revision History - Changes",page);pages.Add(b);double y=477;
  Action next=()=>{b=Page(project,"Revision History - Changes",++page);pages.Add(b);y=457;};
  Action header=()=>{b.Append("0.94 0.94 0.94 rg 30 "+(y-5).ToString(CultureInfo.InvariantCulture)+" 780 19 re f 0 0 0 rg\n");Text(b,"Rev.",34,y,9,true);Text(b,"Part / Phantom Number",80,y,9,true);Text(b,"Description",261,y,9,true);Text(b,"Location",466,y,9,true);Text(b,"Routing",679,y,9,true);Text(b,"Qty change",741,y,9,true);y-=25;};
  if(revisions.Count==0)Text(b,"No saved revisions are available.",34,y,11,false);
  foreach(var revision in revisions){
   if(y<145)next();
   Text(b,"Rev."+revision.Revision+"   "+revision.Date.Replace("T"," ").Replace("Z"," UTC"),34,y,11,true);y-=19;
   foreach(var line in Wrap("Revision notes: "+revision.Notes,125)){if(y<70)next();Text(b,line,34,y,9,false);y-=13;}
   Text(b,"Positive quantities were added. Negative quantities were removed.",34,y,9,false);y-=23;
   if(revision.Changes.Count==0){Text(b,"No item changes in this revision.",34,y,10,false);y-=30;continue;}
   header();
   foreach(var r in revision.Changes){
    var part=Wrap(r.Part,28);var desc=Wrap(r.Description,34);var location=Wrap(r.Location,34);int lines=Math.Max(part.Count,Math.Max(desc.Count,location.Count));
    if(y-lines*12-10<45){next();header();}
    Text(b,"Rev."+r.Revision,34,y,8,false);Text(b,ProjectConfig.Route(r.Routing),685,y,8,false);Text(b,RevisionChanges.Signed(r.Quantity),751,y,9,true);
    for(int line=0;line<lines;line++){if(line<part.Count)Text(b,part[line],80,y,8,r.Kind=="Phantom");if(line<desc.Count)Text(b,desc[line],261,y,8,false);if(line<location.Count)Text(b,location[line],466,y,8,false);y-=12;}y-=8;
   }
   y-=12;
  }
  Save(path,pages);
 }
 public static void WriteUncosted(string path,List<Part> parts,DateTime version,string scope="Full LN Part List"){var p=new Project{Name=scope=="Full LN Part List"?"LN parts without a cost":"Project BoM parts without a cost",Reference="LN version "+version.ToLocalTime().ToString("dd MMM yyyy")};var pages=new List<StringBuilder>();int page=1;var b=Page(p,"Un-costed LN parts",page);pages.Add(b);double y=475;foreach(var part in parts){var lines=Wrap(part.Description,88);if(y<55+lines.Count*12){b=Page(p,"Un-costed LN parts",++page);pages.Add(b);y=475;}Text(b,part.Number,34,y,9,true);foreach(var line in lines){Text(b,line,250,y,9,false);y-=12;}y-=9;}if(parts.Count==0)Text(b,"No un-costed parts in this display.",34,y,11,false);Save(path,pages);}
 static string BannerPath{get{return Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Assets","Armstrong-Banner.jpg");}}
 static string LogoPath{get{return Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Assets","Logo-PDF.jpg");}}
 static void WriteFile(string path,Action<FileStream> write){string temporary=Path.Combine(Path.GetDirectoryName(Path.GetFullPath(path)),"."+Path.GetFileName(path)+"."+Guid.NewGuid().ToString("N")+".tmp");try{using(var stream=new FileStream(temporary,FileMode.CreateNew,FileAccess.Write,FileShare.None)){write(stream);stream.Flush(true);}if(File.Exists(path)){using(var gate=new FileStream(path,FileMode.Open,FileAccess.ReadWrite,FileShare.None)){}File.Replace(temporary,path,null);}else File.Move(temporary,path);}finally{if(File.Exists(temporary))File.Delete(temporary);}}
 static void Save(string path,List<StringBuilder> pages,bool a3=false){bool logo=File.Exists(LogoPath),banner=File.Exists(BannerPath);int logoId=5+pages.Count*2,bannerId=logoId+(logo?1:0);var enc=Encoding.GetEncoding(1252);var objects=new List<byte[]>();Action<string> add=s=>objects.Add(enc.GetBytes(s));add("<< /Type /Catalog /Pages 2 0 R >>");string kids=String.Join(" ",Enumerable.Range(0,pages.Count).Select(i=>(5+i*2)+" 0 R").ToArray());add("<< /Type /Pages /Kids ["+kids+"] /Count "+pages.Count+" >>");add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");for(int i=0;i<pages.Count;i++){add("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 "+(a3?"842 1191":"842 595")+"] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> "+((logo||banner)?"/XObject << "+(logo?"/Brand "+logoId+" 0 R ":"")+(banner?"/Banner "+bannerId+" 0 R ":"")+">> ":"")+">> /Contents "+(6+i*2)+" 0 R >>");byte[] content=enc.GetBytes(pages[i].ToString());using(var m=new MemoryStream()){byte[] pre=enc.GetBytes("<< /Length "+content.Length+" >>\nstream\n");m.Write(pre,0,pre.Length);m.Write(content,0,content.Length);byte[] end=enc.GetBytes("\nendstream");m.Write(end,0,end.Length);objects.Add(m.ToArray());}}
  foreach(string picture in new[]{logo?LogoPath:null,banner?BannerPath:null}.Where(x=>x!=null)){byte[] bytes=File.ReadAllBytes(picture);using(var img=System.Drawing.Image.FromFile(picture))using(var stream=new MemoryStream()){byte[] pre=enc.GetBytes("<< /Type /XObject /Subtype /Image /Width "+img.Width+" /Height "+img.Height+" /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length "+bytes.Length+" >>\nstream\n");stream.Write(pre,0,pre.Length);stream.Write(bytes,0,bytes.Length);byte[] end=enc.GetBytes("\nendstream");stream.Write(end,0,end.Length);objects.Add(stream.ToArray());}}
  WriteFile(path,f=>{Action<string> w=s=>{var bytes=enc.GetBytes(s);f.Write(bytes,0,bytes.Length);};w("%PDF-1.4\n%");f.Write(new byte[]{0xE2,0xE3,0xCF,0xD3,10},0,5);var offsets=new List<long>{0};for(int i=0;i<objects.Count;i++){offsets.Add(f.Position);w((i+1)+" 0 obj\n");f.Write(objects[i],0,objects[i].Length);w("\nendobj\n");}long xref=f.Position;w("xref\n0 "+(objects.Count+1)+"\n0000000000 65535 f \n");foreach(long offset in offsets.Skip(1))w(offset.ToString("0000000000",CultureInfo.InvariantCulture)+" 00000 n \n");w("trailer\n<< /Size "+(objects.Count+1)+" /Root 1 0 R >>\nstartxref\n"+xref+"\n%%EOF\n");});
 }
}
}
