using System;
using System.Linq;
using System.Globalization;
using System.Collections.Generic;
using System.IO;
namespace Armstrong.Bom {
public class BucketDefinition {
 public string Id=Guid.NewGuid().ToString("N"),Name="";public int Number;public decimal Budget;
 public BucketDefinition Copy(){return (BucketDefinition)MemberwiseClone();}
 public override string ToString(){return Number+(String.IsNullOrWhiteSpace(Name)?"":" - "+Name);}
}
public class RoutingDefinition {
 public int Number;public string Name="";
 public RoutingDefinition Copy(){return (RoutingDefinition)MemberwiseClone();}
 public override string ToString(){return Number+(String.IsNullOrWhiteSpace(Name)?"":" - "+Name);}
}
public static class ProjectConfig {
 public static void Ensure(Project p){
  if(!p.Configured){if(p.Buckets.Count==0)for(int i=0;i<10;i++)p.Buckets.Add(new BucketDefinition{Id="legacy-"+(300+i),Number=300+i,Budget=i<p.Budgets.Count?p.Budgets[i]:0});if(p.Routings.Count==0)for(int i=10;i<=90;i+=10)p.Routings.Add(new RoutingDefinition{Number=i});p.Configured=true;}
  foreach(var h in p.History){if(h.Buckets.Count==0)for(int i=0;i<10;i++)h.Buckets.Add(new BucketDefinition{Id="legacy-"+(300+i),Number=300+i,Budget=i<h.Budgets.Count?h.Budgets[i]:0});}
  foreach(var e in p.Items){if(String.IsNullOrEmpty(e.BucketId)){var b=p.Buckets.FirstOrDefault(x=>x.Number==e.Bucket);if(b!=null)e.BucketId=b.Id;}}
  ConsolidatePhantoms(p);
 }
 public static void ConsolidatePhantoms(Project p){
  // Placement identity includes bucket ID and routing; issued history is never rewritten.
  var seen=new Dictionary<string,Entry>(StringComparer.OrdinalIgnoreCase);
  foreach(var e in p.Items.Where(x=>x.Phantom).ToList()){
   string key=e.BucketId+"\u001f"+e.Bucket+"\u001f"+e.Routing+"\u001f"+e.Part;
   Entry first;if(seen.TryGetValue(key,out first)){first.Qty=checked(first.Qty+e.Qty);p.Items.Remove(e);}else seen.Add(key,e);
  }
 }
 public static void Validate(Project p){
  if(!new[]{"GBP","EURO","USD","CAD"}.Contains(p.Currency))throw new InvalidDataException("Select a supported project currency.");
  if(p.Buckets.Any(x=>x.Number<0||x.Number>9999||x.Budget<0)||p.Buckets.Select(x=>x.Id).Distinct().Count()!=p.Buckets.Count||p.Buckets.GroupBy(x=>x.Number+"|"+x.Name.Trim().ToUpperInvariant()).Any(x=>x.Count()>1))throw new InvalidDataException("Use unique bucket number/name pairs and non-negative budgets.");
  if(p.Routings.Any(x=>x.Number<1||x.Number>9999)||p.Routings.Select(x=>x.Number).Distinct().Count()!=p.Routings.Count)throw new InvalidDataException("Use unique routing numbers from 1 to 9999.");
  foreach(var e in p.Items)if(!p.Buckets.Any(x=>x.Id==e.BucketId&&x.Number==e.Bucket))throw new InvalidDataException("Every BoM item must belong to a configured project bucket. Add a project bucket in Print, Help & Options first.");
 }
 public static List<BucketDefinition> Template(bool gcub){string[] names=gcub?new[]{"Long Lead","Enclosure","Pipe fabs","Mechanical","Equipment Positioning","Plumbing","HVAC & Security","Electrical","Cladding Envelope"}:new[]{"Long Lead Items","Base & Superstructure Assembly","Pipe, Mechanical & Equipment Positioning","Electrical Install & Equipment Positioning","Cladding Envelope","Factory Testing","Shipping Prep / Storage","Finishing works","Rework (Unplanned costs)"};return names.Select((n,i)=>new BucketDefinition{Number=300+i,Name=n}).ToList();}
 public static string Symbol(string currency){return currency=="EURO"?"€":currency=="USD"?"US$":currency=="CAD"?"C$":"£";}
 public static string Money(Project p,decimal? value){return value.HasValue?Symbol(p.Currency)+value.Value.ToString("#,##0.00"):"";}
 public static string Route(int number){return number==0?"":number.ToString();}
 public static string BucketLabel(Row r){return r.Bucket+(String.IsNullOrWhiteSpace(r.BucketName)?"":" - "+r.BucketName);}
 public static string GroupKey(Row r){return String.IsNullOrEmpty(r.BucketId)?"legacy-"+r.Bucket:r.BucketId;}
 public static string RouteLabel(Project p,int number){var r=p.Routings.FirstOrDefault(x=>x.Number==number);return number==0?"Unassigned":r==null?number.ToString():r.ToString();}
 public static string FileName(Project p,string report,string filter){string name=String.Join("_",((String.IsNullOrWhiteSpace(p.Reference)?"Project":p.Reference)+" - "+report+(String.IsNullOrWhiteSpace(filter)?"":" - "+filter)).Split(Path.GetInvalidFileNameChars()));return name.Substring(0,Math.Min(76,name.Length))+".pdf";}
 public static void ApplyPrices(Project p,PhantomStore lib,Catalogue cat){
  // The active LN catalogue is the sole price authority. Historical rows remain issued snapshots.
  foreach(var e in p.Items.Where(x=>!x.Phantom)){Part part;e.Cost=cat.ByNumber.TryGetValue(e.Part,out part)?part.Cost:null;}
 }
 public static List<Row> PriceRows(List<Row> rows,Catalogue cat,Project project=null){foreach(var r in rows.Where(x=>!x.Phantom)){Part part;r.Cost=cat.ByNumber.TryGetValue(r.Part,out part)?part.Cost:null;if(project!=null&&r.Cost.HasValue){try{r.Cost=Fx.Convert(r.Cost.Value,part.CostUnit,project.Currency);}catch(IOException){r.Cost=null;}}r.Total=r.Cost.HasValue?(decimal?)(r.Cost.Value*r.Qty):null;}var groups=rows.ToLookup(x=>x.Parent);foreach(var r in rows.AsEnumerable().Reverse().Where(x=>x.Phantom)){var children=groups[r.Path].ToList();r.Total=children.All(x=>x.Total.HasValue)?(decimal?)children.Sum(x=>x.Total.Value):null;r.Cost=r.Total.HasValue?(decimal?)(r.Total.Value/r.Qty):null;}return rows;}
 public static List<Row> Search(List<Row> rows,string query,bool number,bool desc,bool global,Catalogue cat){
  if(String.IsNullOrWhiteSpace(query))return rows;
  var tokens=query.Split((char[])null,StringSplitOptions.RemoveEmptyEntries);var keep=new HashSet<string>();var index=rows.ToDictionary(x=>x.Path);
  foreach(var r in rows){Part p;string text=cat.ByNumber.TryGetValue(r.Part,out p)?p.Global:"";if(tokens.All(t=>(number&&r.Part.IndexOf(t,StringComparison.OrdinalIgnoreCase)>=0)||(desc&&r.Description.IndexOf(t,StringComparison.OrdinalIgnoreCase)>=0)||(global&&(text??"").IndexOf(t,StringComparison.OrdinalIgnoreCase)>=0))){var n=r;while(n!=null){keep.Add(n.Path);n=index.ContainsKey(n.Parent)?index[n.Parent]:null;}}}return Tree.Filter(rows.Where(x=>keep.Contains(x.Path)).ToList(),0,"",0,"");
 }
}
}
