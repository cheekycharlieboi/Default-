@echo off
setlocal
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo .NET Framework C# compiler not found.
  exit /b 1
)
if not exist Build mkdir Build
set "REF=/r:System.Core.dll /r:System.Xml.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.IO.Compression.dll /r:System.IO.Compression.FileSystem.dll"
"%CSC%" /nologo /target:library /optimize+ /out:Build\Armstrong.BoM.Engine.dll %REF% AssemblyInfo.cs Core.cs ProjectConfig.cs PrintPlan.cs CataloguePaths.cs Workbook.cs Pdf.cs RevisionChanges.cs
if errorlevel 1 exit /b 1
"%CSC%" /nologo /target:winexe /optimize+ /win32manifest:app.manifest /win32icon:Armstrong-BoM.ico /out:Build\Armstrong.BoM.Editor.exe %REF% /r:Build\Armstrong.BoM.Engine.dll AssemblyInfo.cs Dialogs.cs PrintOptions.cs EditDialogs.cs ReviewDialogs.cs ProjectOptions.cs MoreOptions.cs App.cs
if errorlevel 1 exit /b 1
"%CSC%" /nologo /target:winexe /define:VIEWER /optimize+ /win32manifest:app.manifest /win32icon:Armstrong-BoM.ico /out:Build\Armstrong.BoM.Viewer.exe %REF% /r:Build\Armstrong.BoM.Engine.dll AssemblyInfo.cs Dialogs.cs PrintOptions.cs EditDialogs.cs ReviewDialogs.cs ProjectOptions.cs MoreOptions.cs App.cs
if errorlevel 1 exit /b 1
"%CSC%" /nologo /target:winexe /optimize+ /win32manifest:app.manifest /win32icon:Armstrong-BoM.ico /out:Build\Uninstall.exe %REF% AssemblyInfo.cs Uninstall.cs
if errorlevel 1 exit /b 1
xcopy /e /i /y "..\Data" "Build\Data" >nul
xcopy /e /i /y "..\Assets" "Build\Assets" >nul
copy /y "..\User-Guide.txt" "Build\User-Guide.txt" >nul
echo Windows executables built in the Build folder.
echo The Setup source is included; the distributed installer embeds a separately hashed Payload ZIP.
endlocal
