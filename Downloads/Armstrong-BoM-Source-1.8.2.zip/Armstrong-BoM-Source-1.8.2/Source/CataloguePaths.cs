using System;using System.IO;using System.Linq;
namespace Armstrong.Bom {
public static class CataloguePaths {
 public static string Resolve(string path){string dir=Path.GetDirectoryName(path);string pointer=Path.Combine(dir,"active-catalogue.txt");if(File.Exists(pointer)){string name=File.ReadAllText(pointer).Trim();if(name==Path.GetFileName(name)&&File.Exists(Path.Combine(dir,name)))return Path.Combine(dir,name);}return path;}
 public static string Dated(string dir){return Path.Combine(dir,"Shared Phantom Items - "+DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss-fff")+".aphantoms");}
 public static void Activate(string path){File.WriteAllText(Path.Combine(Path.GetDirectoryName(path),"active-catalogue.txt"),Path.GetFileName(path));}
}
}
