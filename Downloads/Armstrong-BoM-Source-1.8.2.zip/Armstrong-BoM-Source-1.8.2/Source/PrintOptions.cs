using System;using System.Linq;using System.Drawing;using System.Windows.Forms;using System.Collections.Generic;
namespace Armstrong.Bom {
public class PrintOptions:Form {
 public string Mode="Full BoM",FilterLabel="Full BoM",Sort="part number";public bool Costs,Unpack=false,Descending,CurrentRouting,CurrentBucket,SummaryOwnSheet;public HashSet<int> SelectedRoutes=new HashSet<int>();public HashSet<string> SelectedBuckets=new HashSet<string>();
 RadioButton full=new RadioButton{Text="Full BoM",AutoSize=true},route=new RadioButton{Text="Routing",AutoSize=true},bucket=new RadioButton{Text="Bucket",AutoSize=true};
 CheckBox costs=new CheckBox{Text="Include costs and cost totals",AutoSize=true},unpack=new CheckBox{Text="Unpack",AutoSize=true};CheckBox ownSheet=new CheckBox{Text="Start cost summary on its own sheet",Checked=true,AutoSize=true};ComboBox sort=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,Width=180},direction=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,Width=180};
 public PrintOptions(bool summary,Project project=null,List<Row> rows=null){
  project=project??new Project();ProjectConfig.Ensure(project);Text=summary?"Print cost / budget summary":"Print Project BoM to PDF";Icon=Ui.AppIcon;Width=700;Height=580;MinimumSize=new Size(650,580);StartPosition=FormStartPosition.CenterParent;Font=new Font("Segoe UI",10);
  var panel=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoScroll=true,Padding=new Padding(20)};
  costs.Checked=project.ShowCosts&&Session.CanCost;costs.Enabled=Session.CanCost;SelectedRoutes=new HashSet<int>(project.Routings.Select(x=>x.Number));SelectedRoutes.UnionWith((rows??new List<Row>()).Where(x=>!x.Phantom).Select(x=>x.Routing));foreach(int n in SelectedRoutes.Where(n=>n!=0&&!project.Routings.Any(r=>r.Number==n)).ToList())project.Routings.Add(new RoutingDefinition{Number=n});SelectedBuckets=new HashSet<string>(project.Buckets.Select(x=>x.Id));
  panel.Controls.Add(new Label{Text="Print type",AutoSize=true,Font=new Font(Font,FontStyle.Bold)});panel.Controls.Add(full);panel.Controls.Add(route);
  if(!summary)panel.Controls.Add(bucket);else{full.Text="Summary by bucket";route.Text="Summary by routing";costs.Checked=Session.CanCost;costs.Enabled=false;}
  panel.Controls.Add(new Panel{Name="PrintSectionDivider",Width=590,Height=2,BackColor=Color.Gray,Margin=new Padding(3,12,3,12)});
  panel.Controls.Add(new Label{Text="Print options",AutoSize=true,Font=new Font(Font,FontStyle.Bold)});if(!summary)panel.Controls.Add(unpack);panel.Controls.Add(costs);if(!summary)panel.Controls.Add(ownSheet);ownSheet.Enabled=costs.Checked;costs.CheckedChanged+=(s,e)=>ownSheet.Enabled=costs.Checked;
  var sorting=new FlowLayoutPanel{Width=590,Height=75,Visible=false};sorting.Controls.Add(new Label{Text="Sort By",AutoSize=true});sort.Items.AddRange(new object[]{"part number","description","Quantity","Cost Each"});sort.SelectedIndex=0;sorting.Controls.Add(sort);sorting.Controls.Add(new Label{Text="Direction",AutoSize=true});direction.Items.AddRange(new object[]{"Ascending","Descending"});direction.SelectedIndex=0;sorting.Controls.Add(direction);panel.Controls.Add(sorting);unpack.CheckedChanged+=(s,e)=>sorting.Visible=unpack.Checked;
  var create=Ui.Button("Create PDF",()=>{
   if(!full.Checked&&!route.Checked&&!bucket.Checked)throw new Exception("Choose Full BoM, Routing or Bucket.");
   Mode=summary?(route.Checked?"Summary by routing":"Summary by bucket"):full.Checked?"Full BoM":route.Checked?"Routing":"Bucket";
   if(!summary&&route.Checked&&!Select(project,true))return;if(!summary&&bucket.Checked&&!Select(project,false))return;
   Unpack=!summary&&(route.Checked||unpack.Checked);Costs=costs.Checked&&Session.CanCost;SummaryOwnSheet=ownSheet.Checked;Sort=Convert.ToString(sort.SelectedItem);Descending=direction.SelectedIndex==1;
   FilterLabel=Mode+(route.Checked?(CurrentRouting?" - Current Display":" - "+String.Join(",",SelectedRoutes.OrderBy(x=>x))):bucket.Checked?(CurrentBucket?" - Current Display":" - "+String.Join(",",project.Buckets.Where(x=>SelectedBuckets.Contains(x.Id)).Select(x=>x.ToString()))):"");DialogResult=DialogResult.OK;Close();
  });
  foreach(var radio in new[]{full,route,bucket})radio.CheckedChanged+=(s,e)=>{if(!((RadioButton)s).Checked)return;foreach(var other in new[]{full,route,bucket})if(other!=s)other.Checked=false;if(!summary){unpack.Checked=full.Checked||route.Checked;unpack.Enabled=!route.Checked;}create.Text=summary||full.Checked?"Create PDF":route.Checked?"Select Routing":"Select Buckets";};
  var bar=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=52,Padding=new Padding(10,3,0,0)};bar.Controls.Add(create);var cancel=Ui.Button("Cancel",()=>{DialogResult=DialogResult.Cancel;Close();});bar.Controls.Add(cancel);CancelButton=cancel;Controls.Add(panel);Controls.Add(bar);Controls.Add(new Label{Text=summary?"B041":"B040",Dock=DockStyle.Bottom,Height=20,TextAlign=ContentAlignment.MiddleRight});panel.BringToFront();
 }
 bool Select(Project project,bool routes){using(var f=Ui.Dialog(routes?"Select Routings":"Select Buckets",routes?"B053":"B054",740,560)){
  var list=new CheckedListBox{Dock=DockStyle.Fill,CheckOnClick=true,IntegralHeight=false};var values=routes?project.Routings.Select(x=>x.ToString()).ToList():project.Buckets.Select(x=>x.ToString()).ToList();var numbers=project.Routings.Select(x=>x.Number).ToList();if(routes&&!numbers.Contains(0)){numbers.Insert(0,0);values.Insert(0,"Unassigned");}
  for(int i=0;i<values.Count;i++)list.Items.Add(values[i],routes?SelectedRoutes.Contains(numbers[i]):SelectedBuckets.Contains(project.Buckets[i].Id));
  bool current=routes?CurrentRouting:CurrentBucket;bool bulk=false;var indicator=new Label{Text=current?"Current Display selected":"",AutoSize=true,MaximumSize=new Size(160,0)};
  list.ItemCheck+=(s,e)=>{if(!bulk&&e.NewValue==CheckState.Checked){current=false;indicator.Text="";}};
  var actions=new FlowLayoutPanel{Name="SelectionActions",Dock=DockStyle.Right,Width=180,FlowDirection=FlowDirection.TopDown,WrapContents=false,Padding=new Padding(10)};
  actions.Controls.Add(Ui.Button("Select All",()=>{bulk=true;current=false;indicator.Text="";for(int i=0;i<list.Items.Count;i++)list.SetItemChecked(i,true);bulk=false;}));
  actions.Controls.Add(Ui.Button("De-select All",()=>{bulk=true;current=false;indicator.Text="";for(int i=0;i<list.Items.Count;i++)list.SetItemChecked(i,false);bulk=false;}));
  actions.Controls.Add(Ui.Button("Current Display",()=>{bulk=true;for(int i=0;i<list.Items.Count;i++)list.SetItemChecked(i,false);bulk=false;current=true;indicator.Text="Current Display selected";}));actions.Controls.Add(indicator);
  var bar=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=52,Padding=new Padding(10,3,0,0)};
  var print=Ui.Button("Print to PDF",()=>{if(!current&&list.CheckedIndices.Count==0)throw new Exception("Select at least one item or Current Display.");if(routes){CurrentRouting=current;SelectedRoutes=new HashSet<int>(list.CheckedIndices.Cast<int>().Select(i=>numbers[i]));}else{CurrentBucket=current;SelectedBuckets=new HashSet<string>(list.CheckedIndices.Cast<int>().Select(i=>project.Buckets[i].Id));}f.DialogResult=DialogResult.OK;f.Close();});bar.Controls.Add(print);var cancel=Ui.Button("Cancel",()=>{f.DialogResult=DialogResult.Cancel;f.Close();});bar.Controls.Add(cancel);f.AcceptButton=print;f.CancelButton=cancel;
  var content=new Panel{Dock=DockStyle.Fill,Padding=new Padding(10)};content.Controls.Add(list);content.Controls.Add(new Panel{Name="SelectionDivider",Dock=DockStyle.Right,Width=2,BackColor=Color.Gray});content.Controls.Add(actions);list.BringToFront();f.Controls.Add(content);f.Controls.Add(bar);content.BringToFront();return f.ShowDialog(this)==DialogResult.OK;
 }}
}
}
