using System.Reflection;
[assembly: AssemblyCompany("Armstrong")]
[assembly: AssemblyProduct("Armstrong Bill of Materials")]
[assembly: AssemblyVersion("1.8.2.0")]
[assembly: AssemblyFileVersion("1.8.2.0")]
[assembly: AssemblyCopyright("Armstrong")]

[assembly: System.Runtime.Versioning.TargetFramework(".NETFramework,Version=v4.5", FrameworkDisplayName=".NET Framework 4.5")]
