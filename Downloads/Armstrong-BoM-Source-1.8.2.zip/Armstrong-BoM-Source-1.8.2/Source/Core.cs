using System;
using System.IO;
using System.IO.Compression;
using System.Xml;
using System.Xml.Serialization;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;
using System.Security.Cryptography;

namespace Armstrong.Bom {
public static class Build { public const string Version="1.8.2"; public const string Projects=@"\\server\temporary\Andrei\LN Item Data\LN BoM Software Project Files"; public const string Phantoms=@"\\server\temporary\Andrei\LN Item Data\Shared Phantom Items"; public const string Server=@"\\server\temporary\Andrei\LN Item Data\LN PNo Desc Global Text.xlsx"; }
public class EngineerAccount {public string Name="",Salt="",Hash="";}
public class EngineerAccounts {public List<EngineerAccount> Items=new List<EngineerAccount>();}
public static class Session {
 public static string Engineer="";public static bool ReadOnly,CanCost=true;
 public static readonly string[] Engineers={"Charles Jordan","Ashley Hartill","Mior Siddiq Noor Azam","Lee Hawkes","Sumana Mukhopadhyay","Andrei Cojocaru","Dilani Rajapakshe","Aaron Hindmarsh","Abdel Mumem Elmeselaty","Andrew Taylor","Mohammed Salam"};
 public static string AccountPath{get{return Path.Combine(Build.Projects,"Engineer-Accounts.xml");}}
 static string Hash(string password,string salt){using(var k=new Rfc2898DeriveBytes(password,Convert.FromBase64String(salt),100000))return Convert.ToBase64String(k.GetBytes(32));}
 public static bool Authenticate(string name,string password,string folder=null){
  if(!Engineers.Contains(name))return false;string root=folder??Build.Projects;string path=Path.Combine(root,"Engineer-Accounts.xml");
  if(!Directory.Exists(root))throw new IOException("The default server project folder is unavailable. Engineer login requires the shared accounts folder. View Only without costing remains available.");
  using(var gate=Disk.AcquireLock(path+".lock")){
   var data=File.Exists(path)?Disk.Read<EngineerAccounts>(path,false):new EngineerAccounts();var account=data.Items.FirstOrDefault(x=>x.Name==name);
   if(account==null){if(password!="1234")return false;var salt=new byte[24];using(var rng=RandomNumberGenerator.Create())rng.GetBytes(salt);account=new EngineerAccount{Name=name,Salt=Convert.ToBase64String(salt)};account.Hash=Hash(password,account.Salt);data.Items.Add(account);Disk.Write(path,data,false);}
   return Hash(password,account.Salt)==account.Hash;
  }
 }
 public static void ResetPassword(string oldPassword,string password,string folder=null){string path=Path.Combine(folder??Build.Projects,"Engineer-Accounts.xml");if(ReadOnly||!Engineers.Contains(Engineer))throw new IOException("Engineer login is required.");if(password.Length!=4||password.Any(x=>!Char.IsDigit(x)))throw new IOException("Use four digits.");using(var gate=Disk.AcquireLock(path+".lock")){var data=Disk.Read<EngineerAccounts>(path,false);var account=data.Items.Single(x=>x.Name==Engineer);if(Hash(oldPassword,account.Salt)!=account.Hash)throw new IOException("Current password is incorrect.");account.Hash=Hash(password,account.Salt);Disk.Write(path,data,false);}}
}
public class FxRate {public string Currency="";public decimal PerEuro;}
public class FxData {public string Source="";public string Date="";public List<FxRate> Rates=new List<FxRate>();}
public static class Fx {
 public static string FilePath{get{return Path.Combine(Disk.DataHome,"Currency-Rates.xml");}}
 public static FxData Load(){if(File.Exists(FilePath))return Disk.Read<FxData>(FilePath,false);string bundled=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Data","Currency-Rates.xml");return File.Exists(bundled)?Disk.Read<FxData>(bundled,false):new FxData{Rates=new List<FxRate>{new FxRate{Currency="EUR",PerEuro=1}}};}
 public static void SaveManual(FxData data){DateTime date;if(!DateTime.TryParseExact(data.Date,"yyyy-MM-dd",CultureInfo.InvariantCulture,DateTimeStyles.None,out date)||date.Date>DateTime.Today)throw new IOException("Enter a valid rate date, no later than today.");if(data.Rates.Any(x=>x.PerEuro<=0||Code(x.Currency).Length!=3)||data.Rates.Select(x=>Code(x.Currency)).Distinct().Count()!=data.Rates.Count)throw new IOException("Use unique three-letter currency codes and positive rates.");var euro=data.Rates.SingleOrDefault(x=>Code(x.Currency)=="EUR");if(euro==null||euro.PerEuro!=1)throw new IOException("EUR must equal 1.");Disk.Write(FilePath,data,false);}
 public static string Code(string value){return (value??"").Trim().ToUpperInvariant()=="EURO"?"EUR":(value??"").Trim().ToUpperInvariant();}
 public static decimal Convert(decimal value,string from,string to){from=Code(from);to=Code(to);if(from=="")throw new IOException("LN price currency is missing. Reload the LN workbook with currency codes in column E.");if(from==to)return value;var data=Load();var a=data.Rates.FirstOrDefault(x=>x.Currency==from);var b=data.Rates.FirstOrDefault(x=>x.Currency==to);if(a==null||b==null||a.PerEuro<=0||b.PerEuro<=0)throw new IOException("No verified conversion rate for "+from+" to "+to+". Open Currency Conversions and enter the missing rate manually.");return value*b.PerEuro/a.PerEuro;}

}
public class Entry {
 public string Id=Guid.NewGuid().ToString("N"), Part="", Description="";
 public string Notes=""; public string BucketId=""; public decimal Qty=1; public int Routing=0, Bucket=300; public bool Phantom; public decimal? Cost;
 public Entry Copy(){return (Entry)MemberwiseClone();}
}
public class Phantom {
 public override string ToString(){return Part+" - "+Description;}
 public string Part="",Description=""; public List<Entry> Items=new List<Entry>();
}
public class PhantomData { public string CreatedUtc=""; public string Id=Guid.NewGuid().ToString("N");public long Serial; public List<Phantom> Definitions=new List<Phantom>(); }
public class History {
 public string Revision="",Notes="",Date="",Name="",Reference="",Engineer=""; public int Version; public long PhantomSerial;
 public string Currency="GBP"; public List<BucketDefinition> Buckets=new List<BucketDefinition>();public List<RoutingDefinition> Routings=new List<RoutingDefinition>();
 public List<Row> Rows=new List<Row>(); public List<decimal> Budgets=new List<decimal>();
}
public class Project {
 public string Id=Guid.NewGuid().ToString("N"),Name="",Reference="",Engineer="",ExcelPath="",Revision="",LibraryPath="",LibraryId="";
 public string Currency="GBP"; public bool ShowCosts=false; public bool Configured; public List<BucketDefinition> Buckets=new List<BucketDefinition>();public List<RoutingDefinition> Routings=new List<RoutingDefinition>();
 public int Version; public long PhantomSerial; public string DraftNotes=null; public bool ExcelCosts; public List<Entry> Items=new List<Entry>();
 [XmlIgnore] public List<decimal> Budgets=Enumerable.Repeat(0m,10).ToList();
 // Arrays deserialize by replacement. A pre-populated List is appended to by XmlSerializer.
 [XmlArray("Budgets"),XmlArrayItem("decimal")] public decimal[] BudgetValues {
  get{return Budgets.ToArray();}
  set{var values=value??new decimal[10];Budgets=(values.Length>10&&values.Length%10==0?values.Skip(values.Length-10):values).ToList();}
 }
 public List<History> History=new List<History>();
 public Project CopyForEdit(){
  return new Project{Id=Id,Name=Name,Reference=Reference,Engineer=Engineer,ExcelPath=ExcelPath,Revision=Revision,LibraryPath=LibraryPath,LibraryId=LibraryId,Currency=Currency,ShowCosts=ShowCosts,Configured=Configured,Buckets=Buckets.Select(x=>x.Copy()).ToList(),Routings=Routings.Select(x=>x.Copy()).ToList(),Version=Version,PhantomSerial=PhantomSerial,ExcelCosts=ExcelCosts,DraftNotes=DraftNotes,Items=Items.Select(x=>x.Copy()).ToList(),Budgets=Budgets.ToList(),History=History.ToList()};
 }
}
public class Row {
 public string Path="",Parent="",Part="",Description="",EntryId="",Owner="",BucketId="",BucketName="";
 public string Notes=""; public int Bucket,Routing,Depth; public bool Phantom,BucketHeader; public decimal Qty,LocalQty; public decimal? Cost,Total;
 public Row Copy(){return (Row)MemberwiseClone();}
}
public class Settings {
 public string SortPosition="Phantoms before parts",SortBy="part number",SortDirection="Ascending"; public string LibraryPath="",LastProject=""; public bool Warned; public int ResultLimit=200;
}
public static class Disk {
 public static readonly string Home=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Armstrong","BoM Rebuild");
 public static string DataHome {get {string x=Environment.GetEnvironmentVariable("ARMSTRONG_BOM_TEST_HOME");return String.IsNullOrEmpty(x)?Home:x;}}
 public static string Config {get{return Path.Combine(DataHome,"settings.xml");}}
 public static void Ensure(){Directory.CreateDirectory(DataHome);Directory.CreateDirectory(Path.Combine(DataHome,"sync"));}
 public static T Clone<T>(T value){using(var m=new MemoryStream()){new XmlSerializer(typeof(T)).Serialize(m,value);m.Position=0;return (T)new XmlSerializer(typeof(T)).Deserialize(m);}}
 public static T Read<T>(string path,bool compressed){using(var f=File.Open(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)){if(compressed){using(var gz=new GZipStream(f,CompressionMode.Decompress))return (T)new XmlSerializer(typeof(T)).Deserialize(gz);}return (T)new XmlSerializer(typeof(T)).Deserialize(f);}}
 public static void Write<T>(string path,T value,bool compressed){
  string dir=Path.GetDirectoryName(Path.GetFullPath(path));Directory.CreateDirectory(dir);string tmp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
  try{using(var f=new FileStream(tmp,FileMode.CreateNew,FileAccess.Write,FileShare.None)){if(compressed){using(var gz=new GZipStream(f,CompressionMode.Compress,true))new XmlSerializer(typeof(T)).Serialize(gz,value);}else new XmlSerializer(typeof(T)).Serialize(f,value);f.Flush(true);}Commit(tmp,path);}finally{if(File.Exists(tmp))File.Delete(tmp);}
 }
 public static void SaveProjectRevision(string path,Project candidate,int expectedVersion){Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));using(var gate=AcquireLock(path+".lock")){if(File.Exists(path)){var saved=Read<Project>(path,true);if(saved.Id!=candidate.Id||saved.Version!=expectedVersion)throw new IOException("Another engineer has saved a newer revision. Your edits remain open; reload the saved project before reconciling them.");}else if(expectedVersion!=0)throw new IOException("The saved project is no longer available. No revision was overwritten.");Write(path,candidate,true);}}
 public static FileStream AcquireLock(string path){for(int attempt=0;;attempt++){try{return new FileStream(path,FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);}catch(IOException ex){int code=ex.HResult&65535;if(attempt>=20||(code!=32&&code!=33))throw new IOException("Could not acquire shared-file lock: "+path+". Another user or process may still be saving. Your changes remain open.",ex);Thread.Sleep(100);}}}
 public static void Commit(string tmp,string path){for(int attempt=0;;attempt++){try{if(File.Exists(path))File.Replace(tmp,path,path+".previous",true);else File.Move(tmp,path);return;}catch(IOException ex){int code=ex.HResult&65535;if(attempt>=20||(code!=32&&code!=33))throw new IOException("Could not commit file: "+path+". Changes were not confirmed saved.",ex);Thread.Sleep(100);}}}
 public static string Hash(string s){using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(s))).Replace("-","");}
 public static string NextRevision(string s){if(String.IsNullOrEmpty(s))return "A";var c=s.Replace("-","").ToCharArray();int i=c.Length-1;while(i>=0 && c[i]=='Z'){c[i]='A';i--;}if(i<0)return String.Join("-",("A"+new string(c)).Select(x=>x.ToString()).ToArray());c[i]++;return String.Join("-",c.Select(x=>x.ToString()).ToArray());}
 public static void ValidateEntry(Entry e){if(String.IsNullOrWhiteSpace(e.Part))throw new InvalidDataException("Part number is required.");if(e.Qty<=0)throw new InvalidDataException("Quantity must be greater than zero.");if(e.Routing<0||e.Routing>9999)throw new InvalidDataException("Routing must be blank or a number from 1 to 9999.");if(e.Bucket<0||e.Bucket>9999)throw new InvalidDataException("Invalid bucket number.");if(e.Cost<0)throw new InvalidDataException("Unit cost cannot be negative.");}
 public static void Validate(Project p){if(String.IsNullOrWhiteSpace(p.Name))throw new InvalidDataException("Project name is required.");ProjectConfig.Ensure(p);ProjectConfig.Validate(p);foreach(var e in p.Items)ValidateEntry(e);}
}
public class PhantomStore {
 public readonly string Path; public PhantomData Data; public Dictionary<string,Phantom> Map;
 public PhantomStore(string path){Path=CataloguePaths.Resolve(path);Reload();}
 public void Reload(){if(File.Exists(Path))Data=Disk.Read<PhantomData>(Path,true);else if(Data==null)Data=new PhantomData{CreatedUtc=DateTime.UtcNow.ToString("o")};else if(Data.Definitions.Count>0)throw new IOException("The authoritative shared phantom catalogue is unavailable. It has not been replaced with a local copy.");if(Data.CreatedUtc=="")Data.CreatedUtc=(File.Exists(Path)?File.GetLastWriteTimeUtc(Path):DateTime.UtcNow).ToString("o");Index();Validate(Data);}
 void Index(){Map=Data.Definitions.ToDictionary(x=>x.Part,StringComparer.OrdinalIgnoreCase);}
 public void Save(Phantom value,long expected){
  if(value.Part.Trim().Length==0||value.Part.Length>30||value.Description.Trim().Length==0||value.Description.Length>30)throw new InvalidDataException("Phantom number and description must each contain 1 to 30 characters.");
  Directory.CreateDirectory(System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(Path)));
  using(var gate=new FileStream(Path+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None)){
   var current=File.Exists(Path)?Disk.Read<PhantomData>(Path,true):Disk.Clone(Data);
   if(current.Serial!=expected||current.Id!=Data.Id)throw new IOException("Another user changed the shared phantom catalogue. Reload it before applying this edit.");
   current.Definitions.RemoveAll(x=>String.Equals(x.Part,value.Part,StringComparison.OrdinalIgnoreCase));current.Definitions.Add(Disk.Clone(value));current.Serial++;Validate(current);Disk.Write(Path,current,true);
  }Reload();
 }
 public void Replace(PhantomData candidate,long expected){Directory.CreateDirectory(System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(Path)));using(var gate=new FileStream(Path+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None)){var current=File.Exists(Path)?Disk.Read<PhantomData>(Path,true):Disk.Clone(Data);if(current.Serial!=expected||current.Id!=Data.Id)throw new IOException("The shared phantom catalogue changed. Reload before saving.");candidate.Id=Data.Id;candidate.Serial=expected+1;Validate(candidate);Disk.Write(Path,candidate,true);}Reload();}
 public static void Validate(PhantomData d){
  var map=new Dictionary<string,Phantom>(StringComparer.OrdinalIgnoreCase);
  foreach(var p in d.Definitions){if(String.IsNullOrWhiteSpace(p.Part)||p.Part.Length>30||String.IsNullOrWhiteSpace(p.Description)||p.Description.Length>30)throw new InvalidDataException("Phantom numbers and descriptions must contain 1 to 30 characters.");if(map.ContainsKey(p.Part))throw new InvalidDataException("Duplicate shared phantom: "+p.Part);map.Add(p.Part,p);foreach(var e in p.Items)Disk.ValidateEntry(e);}
  var done=new HashSet<string>(StringComparer.OrdinalIgnoreCase);var active=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  foreach(var key in map.Keys)Visit(key,map,done,active,0);
 }
 static void Visit(string key,Dictionary<string,Phantom> map,HashSet<string> done,HashSet<string> active,int depth){if(depth>40)throw new InvalidDataException("Phantom nesting exceeds 40 levels.");if(active.Contains(key))throw new InvalidDataException("Circular phantom nesting: "+key);if(done.Contains(key))return;if(!map.ContainsKey(key))throw new InvalidDataException("Shared phantom is missing: "+key);active.Add(key);foreach(var e in map[key].Items.Where(x=>x.Phantom))Visit(e.Part,map,done,active,depth+1);active.Remove(key);done.Add(key);}
}
public static class Tree {
 public static bool SameRows(List<Row> a,List<Row> b){if(a.Count!=b.Count)return false;for(int i=0;i<a.Count;i++){var x=a[i];var y=b[i];if(x.Part!=y.Part||x.Description!=y.Description||x.Qty!=y.Qty||x.LocalQty!=y.LocalQty||x.Routing!=y.Routing||x.Bucket!=y.Bucket||x.BucketId!=y.BucketId||x.BucketName!=y.BucketName||x.Cost!=y.Cost||x.Total!=y.Total||x.Phantom!=y.Phantom||x.Owner!=y.Owner||x.Depth!=y.Depth||x.Notes!=y.Notes)return false;}return true;}
 public static List<Row> Expand(Project p,PhantomStore library){ProjectConfig.Ensure(p);var rows=new List<Row>();foreach(var e in p.Items.OrderBy(x=>x.Bucket)){int start=rows.Count;ExpandOne(e,library,rows,"","",e.Bucket,0,1,new HashSet<string>(StringComparer.OrdinalIgnoreCase));var bucket=p.Buckets.FirstOrDefault(x=>x.Id==e.BucketId);for(int i=start;i<rows.Count;i++){rows[i].BucketId=e.BucketId;rows[i].BucketName=bucket==null?"":bucket.Name;}}return rows;}
 static decimal? ExpandOne(Entry e,PhantomStore lib,List<Row> rows,string parent,string owner,int bucket,int depth,decimal factor,HashSet<string> active,int? inheritedRouting=null){
  if(rows.Count>=1000000)throw new InvalidDataException("Expanded BoM exceeds 1,000,000 rows. Reduce repeated nested contents.");
  decimal quantity=checked(factor*e.Qty);var r=new Row{Path=parent+"/"+e.Id,Parent=parent,Part=e.Part,Description=e.Description,Notes=e.Notes,EntryId=e.Id,Owner=owner,Bucket=bucket,Routing=inheritedRouting??e.Routing,Depth=depth,Phantom=e.Phantom,Qty=quantity,LocalQty=e.Qty,Cost=e.Cost};rows.Add(r);
  if(!e.Phantom){r.Total=e.Cost.HasValue?(decimal?)checked(e.Cost.Value*quantity):null;return r.Total;}
  if(!lib.Map.ContainsKey(e.Part))throw new InvalidDataException("Cannot resolve shared phantom "+e.Part+". Connect the authoritative shared catalogue before editing this project.");
  if(!active.Add(e.Part))throw new InvalidDataException("Circular phantom: "+e.Part);
  var def=lib.Map[e.Part];r.Description=def.Description;decimal total=0;bool priced=true;
  foreach(var child in def.Items){var amount=ExpandOne(child,lib,rows,r.Path,e.Part,bucket,depth+1,quantity,active,r.Routing);if(amount.HasValue)total+=amount.Value;else priced=false;}
  active.Remove(e.Part);r.Total=priced?(decimal?)total:null;r.Cost=priced?(decimal?)(total/quantity):null;return r.Total;
 }
 public static List<Row> Filter(List<Row> source,int bucket,string phantom,int routing,string search){
  var keep=new HashSet<string>();var index=source.ToDictionary(x=>x.Path);var parts=(search??"").Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries);
  foreach(var r in source){if(bucket!=0&&r.Bucket!=bucket)continue;if(routing!=0&&(r.Phantom||r.Routing!=routing))continue;
   if(parts.Any(t=>(r.Part+" "+r.Description).IndexOf(t,StringComparison.OrdinalIgnoreCase)<0))continue;
   if(!String.IsNullOrEmpty(phantom)){bool match=false;var n=r;while(n!=null){if(n.Phantom&&String.Equals(n.Part,phantom,StringComparison.OrdinalIgnoreCase)){match=true;break;}n=index.ContainsKey(n.Parent)?index[n.Parent]:null;}if(!match)continue;}
   var cur=r;while(cur!=null){keep.Add(cur.Path);cur=index.ContainsKey(cur.Parent)?index[cur.Parent]:null;}
  }var result=source.Where(x=>keep.Contains(x.Path)).Select(x=>x.Copy()).ToList();var childGroups=result.GroupBy(x=>x.Parent).ToDictionary(x=>x.Key,x=>x.ToList());foreach(var r in result.AsEnumerable().Reverse().Where(x=>x.Phantom)){List<Row> children;if(childGroups.TryGetValue(r.Path,out children)){r.Total=children.All(x=>x.Total.HasValue)?(decimal?)children.Sum(x=>x.Total.Value):null;r.Cost=r.Total.HasValue?(decimal?)(r.Total.Value/r.Qty):null;}else{r.Total=0;r.Cost=0;}}return result;
 }
 public static List<Row> Visible(List<Row> source,HashSet<string> collapsed){var hidden=new HashSet<string>(collapsed);var result=new List<Row>();foreach(var row in source){if(hidden.Contains(row.Parent)){hidden.Add(row.Path);continue;}result.Add(row);}return result;}
 public static List<Row> Leaves(List<Row> rows){return rows.Where(x=>!x.Phantom&&!x.BucketHeader).ToList();}
}
public class Part {public string CostUnit="",Photo="",DataSheet="";public string Number,Description,Global;public decimal? Cost;}
public class Catalogue {
 public List<Part> Parts=new List<Part>();public Dictionary<string,Part> ByNumber=new Dictionary<string,Part>(StringComparer.OrdinalIgnoreCase);public DateTime VersionUtc;public string Source="";
 public void Index(){ByNumber=new Dictionary<string,Part>(StringComparer.OrdinalIgnoreCase);foreach(var p in Parts)if(!ByNumber.ContainsKey(p.Number))ByNumber.Add(p.Number,p);}
 public List<Part> Search(string query,bool number,bool description,bool global,int cap,out int count){
  return Search(query,number,description,global,cap,null,false,CancellationToken.None,out count);
 }
 public List<Part> Search(string query,bool number,bool description,bool global,int cap,IEnumerable<Part> phantoms,bool phantomOnly,CancellationToken cancellation,out int count){
  if(cap<1)throw new ArgumentOutOfRangeException("cap");
  var tokens=(query??"").Split((char[])null,StringSplitOptions.RemoveEmptyEntries);
  var found=new List<Part>(Math.Min(cap,1000));count=0;
  cancellation.ThrowIfCancellationRequested();
  if(tokens.Length==0&&!phantomOnly)return found;
  IEnumerable<Part> source=phantomOnly?(phantoms??Enumerable.Empty<Part>()):Parts;
  if(!phantomOnly&&phantoms!=null)source=source.Concat(phantoms);
  int visited=0;
  foreach(var p in source){
   if((visited++&255)==0)cancellation.ThrowIfCancellationRequested();
   bool ok=true;foreach(var t in tokens){
    if(!((number&&(p.Number??"").IndexOf(t,StringComparison.OrdinalIgnoreCase)>=0)
      ||(description&&(p.Description??"").IndexOf(t,StringComparison.OrdinalIgnoreCase)>=0)
      ||(global&&(p.Global??"").IndexOf(t,StringComparison.OrdinalIgnoreCase)>=0))){ok=false;break;}
   }
   if(ok){count++;if(count<=cap)found.Add(p);else if(count==cap+1)found.Clear();}
  }
  cancellation.ThrowIfCancellationRequested();return found;
 }
 public void Save(string path){string tmp=path+"."+Guid.NewGuid().ToString("N")+".tmp";using(var f=File.Create(tmp))using(var gz=new GZipStream(f,CompressionMode.Compress))using(var w=new BinaryWriter(gz,Encoding.UTF8)){w.Write("APD-LN-2");w.Write(VersionUtc.Ticks);w.Write(Source);w.Write(Parts.Count);foreach(var p in Parts){w.Write(p.Number);w.Write(p.Description);w.Write(p.Global);w.Write(p.Cost.HasValue);if(p.Cost.HasValue)w.Write(p.Cost.Value);w.Write(p.CostUnit??"");w.Write(p.Photo??"");w.Write(p.DataSheet??"");}}Disk.Commit(tmp,path);}
 public static Catalogue Load(string path){var c=new Catalogue();using(var f=File.OpenRead(path))using(var gz=new GZipStream(f,CompressionMode.Decompress))using(var r=new BinaryReader(gz,Encoding.UTF8)){string format=r.ReadString();if(format!="APD-LN-1"&&format!="APD-LN-2")throw new InvalidDataException("Invalid LN index.");c.VersionUtc=new DateTime(r.ReadInt64(),DateTimeKind.Utc);c.Source=r.ReadString();int n=r.ReadInt32();if(n<0||n>3000000)throw new InvalidDataException("Invalid LN record count.");for(int i=0;i<n;i++){var p=new Part{Number=r.ReadString(),Description=r.ReadString(),Global=r.ReadString()};if(r.ReadBoolean())p.Cost=r.ReadDecimal();if(format=="APD-LN-2"){p.CostUnit=r.ReadString();p.Photo=r.ReadString();p.DataSheet=r.ReadString();}c.Parts.Add(p);}}c.Index();return c;}
}
public class SyncJob {public bool Configured;public string Currency="GBP";public List<BucketDefinition> Buckets=new List<BucketDefinition>();public List<RoutingDefinition> Routings=new List<RoutingDefinition>();public string Id=Guid.NewGuid().ToString("N"),ProjectId="",Target="",Name="",Reference="",Engineer="",Revision="",Date="",Notes="";public int Version;public bool Costs;public List<Row> Rows=new List<Row>();public List<decimal> Budgets=new List<decimal>();public List<History> History=new List<History>();}
public static class Sync {
 public static string Queue(Project p,List<Row> rows){Disk.Ensure();var j=new SyncJob{Configured=p.Configured,Currency=p.Currency,Buckets=p.Buckets.Select(x=>x.Copy()).ToList(),Routings=p.Routings.Select(x=>x.Copy()).ToList(),ProjectId=p.Id,Target=p.ExcelPath,Name=p.Name,Reference=p.Reference,Engineer=p.Engineer,Revision=p.Revision,Version=p.Version,Date=DateTime.UtcNow.ToString("o"),Costs=p.ExcelCosts,Rows=rows,Budgets=p.Budgets,History=p.History.Select(h=>new History{Name=h.Name,Reference=h.Reference,Engineer=h.Engineer,Revision=h.Revision,Version=h.Version,Date=h.Date,Notes=h.Notes,PhantomSerial=h.PhantomSerial}).ToList()};string path=Path.Combine(Disk.DataHome,"sync",DateTime.UtcNow.Ticks+"-"+j.Id+".job");Disk.Write(path,j,true);return path;}
 public static void Retarget(string projectId,string target){foreach(string path in Directory.GetFiles(System.IO.Path.Combine(Disk.DataHome,"sync"),"*.job")){try{var j=Disk.Read<SyncJob>(path,true);if(j.ProjectId==projectId){j.Target=target;Disk.Write(path,j,true);}}catch(FileNotFoundException){}}}
 public static bool ProcessOne(string job){var j=Disk.Read<SyncJob>(job,true);if(j.Budgets.Count>10&&j.Budgets.Count%10==0)j.Budgets=j.Budgets.Skip(j.Budgets.Count-10).ToList();string dir=Path.GetDirectoryName(Path.GetFullPath(j.Target));if(!Directory.Exists(dir))throw new IOException("Backup destination is unavailable: "+dir);if(File.Exists(j.Target)){string owner=Xlsx.ProjectId(j.Target);if(owner!=""&&owner!=j.ProjectId)throw new IOException("The selected Excel file belongs to another project. Choose a separate backup file in Project details.");}string tmp=Path.Combine(dir,"."+Path.GetFileName(j.Target)+"."+j.Id+".tmp.xlsx");try{Xlsx.Export(j,tmp);using(var z=ZipFile.OpenRead(tmp)){if(z.GetEntry("xl/workbook.xml")==null)throw new IOException("Workbook verification failed.");}var verified=Xlsx.Import(tmp,true);if(verified.Roots.Count!=j.Rows.Count(x=>x.Parent==""))throw new IOException("Workbook row verification failed.");using(var gate=new FileStream(job+".commitlock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None)){if(File.Exists(job+".cancel")){if(File.Exists(job))File.Move(job,job+".cancelled");return false;}Disk.Commit(tmp,j.Target);File.Delete(job);}if(File.Exists(job+".error"))File.Delete(job+".error");return true;}finally{if(File.Exists(tmp))File.Delete(tmp);}}
 public static void Cancel(string job){using(var gate=new FileStream(job+".commitlock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None)){if(!File.Exists(job))throw new IOException("This backup has already completed or is no longer queued. Refresh the list.");File.WriteAllText(job+".cancel",DateTime.UtcNow.ToString("o"));File.Move(job,job+".cancelled");if(File.Exists(job+".error"))File.Delete(job+".error");}}
 public static void Run(){Disk.Ensure();using(var mutex=new Mutex(false,"ArmstrongBomSync-"+Disk.Hash(Disk.DataHome))){bool acquired;try{acquired=mutex.WaitOne(3000);}catch(AbandonedMutexException){acquired=true;}if(!acquired)return;try{while(true){var jobs=Directory.GetFiles(Path.Combine(Disk.DataHome,"sync"),"*.job").OrderBy(x=>x).ToArray();if(jobs.Length==0)return;var blocked=new HashSet<string>(StringComparer.OrdinalIgnoreCase);foreach(var job in jobs){try{var data=Disk.Read<SyncJob>(job,true);if(blocked.Contains(data.Target))continue;ProcessOne(job);}catch(Exception ex){try{blocked.Add(Disk.Read<SyncJob>(job,true).Target);File.WriteAllText(job+".error",DateTime.Now.ToString("s")+" "+ex.Message);}catch{}}}if(Directory.GetFiles(Path.Combine(Disk.DataHome,"sync"),"*.job").Length==0)return;Thread.Sleep(15000);}}finally{mutex.ReleaseMutex();}}}
}
}
