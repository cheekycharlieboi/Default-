"""Package the unified Armstrong BoM installer. Build executables before running."""
import argparse,hashlib,os,re,shutil,subprocess,tempfile,zipfile
from pathlib import Path
source=Path(__file__).resolve().parent
root=source.parent
version=re.search(r'Version="([\d.]+)"',(source/'Core.cs').read_text()).group(1)
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--compiler',default=os.environ.get('CSC','csc'))
p.add_argument('--build-dir',type=Path,default=source/'Build')
p.add_argument('--output-dir',type=Path,default=root/'Release')
a=p.parse_args();build=a.build_dir.resolve();out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
files={}
for name in ['Armstrong.BoM.Engine.dll','Armstrong.BoM.Editor.exe','Uninstall.exe']:
 files[name]=(build/name).read_bytes()
for directory in ['Data','Assets','Source']:
 for f in sorted((root/directory).rglob('*')):
  if f.is_file() and not any(x in ['Build','__pycache__','.git'] for x in f.relative_to(root/directory).parts):files[f.relative_to(root).as_posix()]=f.read_bytes()
notes='Release-Notes-'+version+'.md';validation='Validation-'+version+'.txt'
for name in ['User-Guide.txt',notes,validation]:files[name]=(root/name).read_bytes()
files['SHA256SUMS.txt']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
setup=out/('Armstrong-BoM-Setup-'+version+'.exe')
with tempfile.TemporaryDirectory(prefix='armstrong-unified-') as temp:
 payload=Path(temp)/'Payload.zip'
 with zipfile.ZipFile(payload,'w',zipfile.ZIP_DEFLATED) as z:
  for name,data in sorted(files.items()):z.writestr(name,data)
 with zipfile.ZipFile(payload) as z:
  assert z.testzip() is None
  for line in z.read('SHA256SUMS.txt').decode().splitlines():assert hashlib.sha256(z.read(line[66:])).hexdigest()==line[:64]
  assert 'Armstrong.BoM.Viewer.exe' not in z.namelist()
 refs=['-r:'+x+'.dll' for x in ['System.Core','System.Xml','System.Drawing','System.Windows.Forms','System.IO.Compression','System.IO.Compression.FileSystem']]
 subprocess.run([a.compiler,'-nologo','-target:winexe','-optimize+','-out:'+str(setup),'-win32manifest:'+str(source/'app.manifest'),'-win32icon:'+str(source/'Armstrong-BoM.ico')]+refs+['-resource:'+str(payload)+',Payload','-resource:'+str(root/'Assets/Armstrong-Banner.jpg')+',BrandBanner','-resource:'+str(root/'Assets/Armstrong-Logo.png')+',BrandLogo','-resource:'+str(source/'Armstrong-BoM.ico')+',BrandIcon',str(source/'AssemblyInfo.cs'),str(source/'Setup.cs')],check=True)
shutil.copyfile(build/'Uninstall.exe',out/'Uninstall-Armstrong-BoM.exe')
for name in [notes,validation]:shutil.copyfile(root/name,out/name)
(out/'INSTALL.txt').write_text('Armstrong BoM '+version+'\nExtract the ZIP and run '+setup.name+'.\nOne application provides engineer editing and both view-only levels at login.\nEngineer default PIN: 1234. Costed view-only PIN: 1934. Public view-only needs no password.\nAccounts and password resets are shared in the configured default project folder.\nClose application windows before updating. Back up your projects and shared catalogue first.\nRequires Windows and .NET Framework 4.5 or later. No Excel or Python is needed by users.\nInstalls per Windows user into the existing BoM Studio 1 folder.\nProjects, shared phantom catalogues and backups remain outside the application folder.\nThe older separately installed Viewer is not removed automatically; uninstall it separately if no longer needed.\nInstallers are unsigned. Native Windows installation/UNC/DPI acceptance remains untested.\n',encoding='utf-8')
names=[setup.name,'Uninstall-Armstrong-BoM.exe',notes,validation,'INSTALL.txt']
(out/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256((out/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in names))
bundle=out/('Armstrong-BoM-Windows-Installer-'+version+'.zip')
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
 for name in names+['SHA256SUMS.txt']:z.write(out/name,name)
print('Verified hashed payload entries:',len(files)-1)
print('Created',bundle)
