using System;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
namespace Armstrong.Bom {
public class RevisionChange {
 public string Revision="",Date="",Notes="",Part="",Description="",Location="",Kind="",Path="";
 public int Bucket,Routing; public decimal Quantity; public decimal? UnitCost;
}
public class RevisionDelta {
 public string Revision="",Date="",Notes="";public List<RevisionChange> Changes=new List<RevisionChange>();
}
public static class RevisionChanges {
 static string Key(Row r){
  // Derived phantom prices are not edits to the phantom occurrence itself.
  return String.Join("\u001f",new[]{r.Path,r.BucketId,r.BucketName,r.Bucket.ToString(CultureInfo.InvariantCulture),r.Part.ToUpperInvariant(),r.Routing.ToString(CultureInfo.InvariantCulture),r.Phantom?"Phantom":"Part",r.Description,r.Phantom?"":r.Cost.HasValue?r.Cost.Value.ToString("G29",CultureInfo.InvariantCulture):"Unpriced"});
 }
 static string Location(Row r,Dictionary<string,Row> rows){
  var names=new List<string>();Row parent;
  string key=r.Parent;int depth=0;
  while(key!=""&&rows.TryGetValue(key,out parent)&&depth++<50){names.Add(parent.Part);key=parent.Parent;}
  names.Reverse();return "Bucket "+ProjectConfig.BucketLabel(r)+(names.Count==0?"":" / "+String.Join(" / ",names.ToArray()));
 }
 static RevisionChange Change(History h,Row r,decimal quantity,Dictionary<string,Row> rows){
  return new RevisionChange{Revision=h.Revision,Date=h.Date,Notes=h.Notes,Part=r.Part,Description=r.Description,Location=Location(r,rows),Kind=r.Phantom?"Phantom":"Part",Path=r.Path,Bucket=r.Bucket,Routing=r.Routing,Quantity=quantity,UnitCost=r.Phantom?null:r.Cost};
 }
 public static List<RevisionDelta> Build(Project project,string revision){
  var result=new List<RevisionDelta>();var previous=new List<Row>();
  foreach(var h in project.History){
   if(String.IsNullOrEmpty(revision)||String.Equals(revision,h.Revision,StringComparison.OrdinalIgnoreCase)){
    var delta=new RevisionDelta{Revision=h.Revision,Date=h.Date,Notes=h.Notes};
    var oldIndex=previous.Where(x=>!x.BucketHeader).ToDictionary(x=>x.Path);
    var newIndex=h.Rows.Where(x=>!x.BucketHeader).ToDictionary(x=>x.Path);
    var oldRows=previous.Where(x=>!x.BucketHeader).ToDictionary(Key);
    var newRows=h.Rows.Where(x=>!x.BucketHeader).ToDictionary(Key);
    foreach(var r in previous.Where(x=>!x.BucketHeader)){
     Row current;if(!newRows.TryGetValue(Key(r),out current))delta.Changes.Add(Change(h,r,-r.Qty,oldIndex));
     else if(current.Qty<r.Qty)delta.Changes.Add(Change(h,r,current.Qty-r.Qty,oldIndex));
    }
    foreach(var r in h.Rows.Where(x=>!x.BucketHeader)){
     Row old;if(!oldRows.TryGetValue(Key(r),out old))delta.Changes.Add(Change(h,r,r.Qty,newIndex));
     else if(r.Qty>old.Qty)delta.Changes.Add(Change(h,r,r.Qty-old.Qty,newIndex));
    }
    result.Add(delta);
   }
   previous=h.Rows;
  }
  return result;
 }
 public static string Signed(decimal quantity){return quantity.ToString("+0.###;-0.###;0",CultureInfo.InvariantCulture);}
}
}
